import './Donation.css'
import { Link, useNavigate } from 'react-router-dom';

export const Donation = () => {
    const navigate = useNavigate();
    return (
        <>
            <main className="container my-5 flex-grow-1">
                <div className="donor-1 mb-5 text-center">
                    <h1>Become a Blood Donor</h1>
                    <p>Your decision to donate blood can save lives. Join our community of donors and make a difference today.</p>
                    <button className="donate-btn-2 mx-auto d-block" onClick={() => navigate('/login')}>Sign Up to Donate</button>
                </div>

                <div className="bloodTypes">
                    <h2 className="text-center">Know Your Blood Group</h2>
                    <div className="row justify-content-center mt-4 g-4">
                        <div className="col-sm-6 col-md-4 col-lg-3">
                            <div className="bloodtype d-flex flex-column h-100">
                                <img src="../Images/images.png" alt="" />
                                <h3>A Positive (A+)</h3>
                                <p>A+ is one of the most common blood types...</p>
                                <button className="donate-btn mt-auto">Add to Favourites</button>
                                <Link className="text-decoration-none text-danger fw-bold fs-5 mt-3" to="/bpositive">Details</Link>
                            </div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg-3">
                            <div className="bloodtype d-flex flex-column h-100">
                                <img src="../Images/a-.png" alt="" />
                                <h3>A Negative (A-)</h3>
                                <p>A- is a rarer blood type...</p>
                                <button className="donate-btn mt-auto">Add to Favourites</button>
                                <Link className="text-decoration-none text-danger fw-bold fs-5 mt-3" to="/bpositive">Details</Link>
                            </div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg-3">
                            <div className="bloodtype d-flex flex-column h-100">
                                <img src="../Images/b+.png" alt="" />
                                <h3>B Positive (B+)</h3>
                                <p>B+ is found in about 10% of people...</p>
                                <button className="donate-btn mt-auto">Add to Favourites</button>
                                <Link className="text-decoration-none text-danger fw-bold fs-5 mt-3" to="/bpositive">Details</Link>
                            </div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg-3">
                            <div className="bloodtype d-flex flex-column h-100">
                                <img src="../Images/b-.jpg" alt="" />
                                <h3>B Negative (B-)</h3>
                                <p>B- is one of the rarest types...</p>
                                <button className="donate-btn mt-auto">Add to Favourites</button>
                                <Link className="text-decoration-none text-danger fw-bold fs-5 mt-3" to="/bpositive">Details</Link>
                            </div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg-3">
                            <div className="bloodtype d-flex flex-column h-100">
                                <img src="../Images/ab+.png" alt="" />
                                <h3>AB Positive (AB+)</h3>
                                <p>AB+ is known as the "universal plasma donor" type...</p>
                                <button className="donate-btn mt-auto">Add to Favourites</button>
                                <Link className="text-decoration-none text-danger fw-bold fs-5 mt-3" to="/bpositive">Details</Link>
                            </div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg-3">
                            <div className="bloodtype d-flex flex-column h-100">
                                <img src="../Images/ab-.jpg" alt="" />
                                <h3>AB Negative (AB-)</h3>
                                <p>AB- is the rarest blood type in the world...</p>
                                <button className="donate-btn mt-auto">Add to Favourites</button>
                                <Link className="text-decoration-none text-danger fw-bold fs-5 mt-3" to="/bpositive">Details</Link>
                            </div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg-3">
                            <div className="bloodtype d-flex flex-column h-100">
                                <img src="../Images/O+.png" alt="" />
                                <h3>O Positive (O+)</h3>
                                <p>O+ is a common blood type and can donate to O+ and AB+...</p>
                                <button className="donate-btn mt-auto">Add to Favourites</button>
                                <Link className="text-decoration-none text-danger fw-bold fs-5 mt-3" to="/bpositive">Details</Link>
                            </div>
                        </div>
                        <div className="col-sm-6 col-md-4 col-lg-3">
                            <div className="bloodtype d-flex flex-column h-100">
                                <img src="../Images/O-.png" alt="" />
                                <h3>O Negative (O-)</h3>
                                <p>O- is the universal donor blood type...</p>
                                <button className="donate-btn mt-auto">Add to Favourites</button>
                                <Link className="text-decoration-none text-danger fw-bold fs-5 mt-3" to="/bpositive">Details</Link>
                            </div>
                        </div>
                    </div>
                </div>

                <section className="donor-1 my-5 text-center">
                    <h1>Become a Donor Today</h1>
                    <p>Every drop of blood you donate can help save a life. Whether your blood type is common or rare, your contribution matters. Join SRC Blood Donation and become part of a life-saving mission.</p>
                    <p><b>Be a hero — Donate Blood, Save Lives!</b></p>
                    <button className="donate-btn-2 mx-auto d-block" onClick={() => navigate('/login')}>Sign Up to Donate</button>
                </section>
            </main>
        </>
    );
}