import './Favourite.css'

export const Favourite = () => {
    return (
        <>
            <div className="container my-5">
                <h2 className="text-center text-danger fw-bold mb-4">Your Favorite Blood Types</h2>
                <p className="text-center text-muted mb-5">Here are the blood types you’ve marked as favorites.</p>

                <div className="row justify-content-center g-4">
                    <div className="col-md-4 col-sm-6">
                        <div className="favorite-card">
                            <h4 className="text-danger">B Positive (B+)</h4>
                            <p>Can donate to B+ and AB+. Receives from B+ and B−, O+ and O−.</p>
                            <button className="btn btn-outline-danger btn-sm">Remove</button>
                        </div>
                    </div>

                    <div className="col-md-4 col-sm-6">
                        <div className="favorite-card">
                            <h4 className="text-danger">O Positive (O+)</h4>
                            <p>Most common type. Can donate to all positive types.</p>
                            <button className="btn btn-outline-danger btn-sm">Remove</button>
                        </div>
                    </div>

                    <div className="col-md-4 col-sm-6">
                        <div className="favorite-card">
                            <h4 className="text-danger">A Positive (A+)</h4>
                            <p>Can donate to A+ and AB+. Common among donors.</p>
                            <button className="btn btn-outline-danger btn-sm">Remove</button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}