import {useNavigate } from 'react-router-dom';


export const Bpositive = () => {
  const navigate = useNavigate();
  return (
    <>
      <main className="flex-grow-1">
        <div className="container my-5">
          <h2 className="text-center text-danger fw-bolder fs-1">
            B Positive (B+)
          </h2>

          <p className="text-center fs-5 text-secondary mb-5">
            Most common and important blood type in the world.
          </p>

          <div className="row align-items-center">
            <div className="col-md-5 text-center">
              <img
                src="/Images/b+.png"
                alt="B Positive Blood Type"
                className="img-fluid rounded shadow-sm"
                style={{ maxWidth: "300px" }}
              />
            </div>

            <div className="col-md-7">
              <h3 className="fw-bold text-danger mb-3">Overview</h3>
              <p className="fs-5 text-dark">
                B Positive (B+) is one of the eight main blood groups and is found
                in about <strong>9% of the global population</strong>. People with
                B+ blood have B antigens on the surface of their red blood cells
                and the Rh(D) antigen, making them Rh positive.
              </p>

              <h3 className="fw-bold text-danger mt-4 mb-3">
                Compatibility
              </h3>
              <ul className="fs-5 text-dark">
                <li>
                  <strong>Can receive blood from:</strong> B+, B-, O+, and O-
                </li>
                <li>
                  <strong>Can donate blood to:</strong> B+ and AB+
                </li>
              </ul>

              <h3 className="fw-bold text-danger mt-4 mb-3">
                Why B+ Donors Are Important
              </h3>
              <p className="fs-5 text-dark">
                Since B+ is a relatively common type, hospitals need a steady
                supply of it for patients with this blood group. B+ donors also
                play a crucial role in platelet and plasma donations used for
                cancer, trauma, and surgery patients.
              </p>
            </div>
          </div>

          <div className="mt-5 text-center">
            <h4 className="fw-bold text-danger">Did You Know?</h4>
            <p className="fs-5 text-dark">
              People with B+ blood are often encouraged to donate regularly
              because their blood can help both B and AB positive patients.
              Every donation can save up to <strong>three lives</strong>!
            </p>
          </div>
        </div>
        <br /><br />
        <button className="donate-btn-2 mx-auto d-block" onClick={() => navigate('/donation')}>Go Back</button>
        <br /><br /><br />
      </main>
    </>
  );
};
