export const Footbar = () => {
    return (
        <>
            <footer className="bg-dark text-white text-center p-2">
                <p className="m-0">&copy; 2025 SRC Blood Donation. All rights reserved.</p>
            </footer>
        </>
    );
}