import './Login.css'

export const Login = () => {
    return (
        <>
            <div className="login-container d-flex justify-content-center align-items-center">
                <form className="text-white">
                    <h2>Welcome Back</h2>
                    <p>Sign in to your account</p>

                    <label for="username">Username</label>
                    <input type="text" id="username" className="form-control" placeholder="Enter your username" required />

                    <label for="password">Password</label>
                    <input type="password" id="password" className="form-control" placeholder="Enter your password" required />

                    <div className="options d-flex justify-content-between align-items-center">
                        <label><input type="checkbox" /> Remember me</label>
                        <a href="#">Forgot password?</a>
                    </div>

                    <button type="submit" className="login-button btn btn-light w-100">Sign In</button>

                    <p className="register mt-3">New to SRC Blood Donation? <a href="#">Create account</a></p>
                </form>
            </div>

        </>
    );
}