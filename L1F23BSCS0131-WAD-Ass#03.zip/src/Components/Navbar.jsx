import React from "react";
import { Link } from "react-router-dom";
export const Navbar = () => {
    return (
        <>
            <header className="bg-danger text-white p-3">
                <div className="container d-flex justify-content-between align-items-center">
                    <h1 className="m-0">SRC Blood Donation</h1>
                    <ul className="d-flex list-unstyled m-0 gap-3">
                        <li><Link to="/" className="text-white text-decoration-none">Home</Link></li>
                        <li><Link to="/about" className="text-white text-decoration-none">About Us</Link></li>
                        <li><Link to="/donation" className="text-white text-decoration-none">Blood Types</Link></li>
                        <li><Link to="/login" className="text-white text-decoration-none">Login</Link></li>
                        <li><Link to="/favourite" className="text-white text-decoration-none">Favourites</Link></li>
                    </ul>
                </div>
            </header>
        </>
    );

}