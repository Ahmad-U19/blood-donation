import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { Navbar } from './Components/Navbar'
import { Footbar } from './Components/Footbar'
import { Home } from './Components/Home'
import { About } from './Components/About'
import { Donation } from './Components/Donation'
import { Login } from './Components/Login'
import { Favourite } from './Components/Favourite'
import { Bpositive } from './Components/Bpositive'


function App() {
  return (
    <BrowserRouter>
    <div className="app-wrapper">

      <Navbar />
      
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/donation" element={<Donation />} />
          <Route path="/login" element={<Login />} />
          <Route path="/favourite" element={<Favourite />} />
          <Route path="/bpositive" element={<Bpositive />} />
        </Routes>

      <Footbar />
    </div>
    </BrowserRouter>
  );
}


export default App
